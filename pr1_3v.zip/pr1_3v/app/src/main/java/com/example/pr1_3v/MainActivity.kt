package com.example.pr1_3v

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var button:Button
    lateinit var login: EditText
    lateinit var password: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button=findViewById(R.id.ButtonSingIn)
        login=findViewById(R.id.Login)
        password=findViewById(R.id.Password)
        button.setOnClickListener{
            if(login.text.isNotEmpty() && password.text.isNotEmpty()){
                val sharedPreferences = getSharedPreferences("User", MODE_PRIVATE)
                val loginsh = sharedPreferences.getString("login", "")
                val passwordsh = sharedPreferences.getString("password", "")
                if(loginsh==login.text.toString()&&passwordsh==password.text.toString()){
                    var intent=Intent(this, MainActivity2::class.java)
                    startActivity(intent)
                }
                else{
                    showAlert("Неверный логин или пароль")
                }
            }
            if(login.text.isEmpty()||password.text.isEmpty()){
                showAlert("Введите логин или пароль")
            }

        }
        val sharedPreferences = getSharedPreferences("User", MODE_PRIVATE)
        val ed: SharedPreferences.Editor = sharedPreferences.edit()
        ed.putString("login", "ects")
        ed.putString("password", "ects2023")
        ed.apply()
    }
    private fun showAlert(message: String){
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                dialog, _ -> dialog.dismiss()
        }.show()
    }
}