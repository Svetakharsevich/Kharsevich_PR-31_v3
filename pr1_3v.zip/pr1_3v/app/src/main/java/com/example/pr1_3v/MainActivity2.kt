package com.example.pr1_3v

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener


class MainActivity2 : AppCompatActivity() {
    lateinit var ex:ImageButton
    lateinit var ButtonСalculate: Button
    lateinit var editText: EditText
    lateinit var spinner: Spinner
    lateinit var textview:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        ex=findViewById(R.id.exit)
        spinner = findViewById(R.id.spinner)
        editText=findViewById(R.id.editText)
        ButtonСalculate=findViewById(R.id.ButtonСalculate)
        textview=findViewById(R.id.choice)
        ArrayAdapter.createFromResource(this,R.array.apartment_array,android.R.layout.simple_spinner_item).also {
                adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }
        spinner.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

                when (position) {
                    0 -> textview.setText("1-о комнатная квартира")
                    1 -> textview.setText("2-х комнатная квартира")
                    2 -> textview.setText("3-x комнатная квартира")
                    3 -> textview.setText("Студия")
                }
            }

            override fun onNothingSelected(arg0: AdapterView<*>?) {}
        }
        ex.setOnClickListener {
            var intent=Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        ButtonСalculate.setOnClickListener{
            if(editText.text.isEmpty()){
                showAlert("Введите количество метров")
            }
            val loanTerm = editText.text.toString().toInt()
            val sp=spinner.selectedItemPosition
            var intent=Intent(this, MainActivity3::class.java)
            intent.putExtra("loanTerm", loanTerm)
            intent.putExtra("sp", sp)
            startActivity(intent)
        }
    }
    private fun showAlert(message: String){
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                dialog, _ -> dialog.dismiss()
        }.show()
    }
}