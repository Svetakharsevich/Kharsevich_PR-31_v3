package com.example.pr1_3v

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    lateinit var breturn:Button
    lateinit var itog: TextView
    lateinit var rez: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        breturn=findViewById(R.id.ButtonReturn)
        itog=findViewById(R.id.itog)
        rez=findViewById(R.id.rezult)
        var price=1000
        val itogMetr=intent.getIntExtra("loanTerm", 0)
        itog.text="количество метров: $itogMetr м."
        val i=intent.getIntExtra("sp", 0)
        var result=0.0
        when(i){
            0->{result=price*itogMetr*1.4}
            1->{result=price*itogMetr*1.0}
            2->{result=price*itogMetr*0.8}
            3->{result=price*itogMetr*1.1}
        }
        rez.text="результат $result"
        breturn.setOnClickListener{
            var intent=Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}